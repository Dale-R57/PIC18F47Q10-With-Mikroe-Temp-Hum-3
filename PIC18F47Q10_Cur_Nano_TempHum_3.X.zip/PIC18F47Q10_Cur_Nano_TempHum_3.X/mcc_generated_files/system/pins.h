/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA6 aliases
#define DRY_INT_TRIS                 TRISAbits.TRISA6
#define DRY_INT_LAT                  LATAbits.LATA6
#define DRY_INT_PORT                 PORTAbits.RA6
#define DRY_INT_WPU                  WPUAbits.WPUA6
#define DRY_INT_OD                   ODCONAbits.ODCA6
#define DRY_INT_ANS                  ANSELAbits.ANSELA6
#define DRY_INT_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define DRY_INT_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define DRY_INT_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define DRY_INT_GetValue()           PORTAbits.RA6
#define DRY_INT_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define DRY_INT_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)
#define DRY_INT_SetPullup()          do { WPUAbits.WPUA6 = 1; } while(0)
#define DRY_INT_ResetPullup()        do { WPUAbits.WPUA6 = 0; } while(0)
#define DRY_INT_SetPushPull()        do { ODCONAbits.ODCA6 = 0; } while(0)
#define DRY_INT_SetOpenDrain()       do { ODCONAbits.ODCA6 = 1; } while(0)
#define DRY_INT_SetAnalogMode()      do { ANSELAbits.ANSELA6 = 1; } while(0)
#define DRY_INT_SetDigitalMode()     do { ANSELAbits.ANSELA6 = 0; } while(0)

// get/set RB1 aliases
#define SCL1_TRIS                 TRISBbits.TRISB1
#define SCL1_LAT                  LATBbits.LATB1
#define SCL1_PORT                 PORTBbits.RB1
#define SCL1_WPU                  WPUBbits.WPUB1
#define SCL1_OD                   ODCONBbits.ODCB1
#define SCL1_ANS                  ANSELBbits.ANSELB1
#define SCL1_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define SCL1_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define SCL1_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define SCL1_GetValue()           PORTBbits.RB1
#define SCL1_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define SCL1_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define SCL1_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define SCL1_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define SCL1_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define SCL1_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define SCL1_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define SCL1_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB2 aliases
#define SDA1_TRIS                 TRISBbits.TRISB2
#define SDA1_LAT                  LATBbits.LATB2
#define SDA1_PORT                 PORTBbits.RB2
#define SDA1_WPU                  WPUBbits.WPUB2
#define SDA1_OD                   ODCONBbits.ODCB2
#define SDA1_ANS                  ANSELBbits.ANSELB2
#define SDA1_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define SDA1_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define SDA1_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define SDA1_GetValue()           PORTBbits.RB2
#define SDA1_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define SDA1_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define SDA1_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define SDA1_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define SDA1_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define SDA1_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define SDA1_SetAnalogMode()      do { ANSELBbits.ANSELB2 = 1; } while(0)
#define SDA1_SetDigitalMode()     do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set RD0 aliases
#define TX2_TRIS                 TRISDbits.TRISD0
#define TX2_LAT                  LATDbits.LATD0
#define TX2_PORT                 PORTDbits.RD0
#define TX2_WPU                  WPUDbits.WPUD0
#define TX2_OD                   ODCONDbits.ODCD0
#define TX2_ANS                  ANSELDbits.ANSELD0
#define TX2_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define TX2_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define TX2_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define TX2_GetValue()           PORTDbits.RD0
#define TX2_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define TX2_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define TX2_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define TX2_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define TX2_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define TX2_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define TX2_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define TX2_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define RX2_TRIS                 TRISDbits.TRISD1
#define RX2_LAT                  LATDbits.LATD1
#define RX2_PORT                 PORTDbits.RD1
#define RX2_WPU                  WPUDbits.WPUD1
#define RX2_OD                   ODCONDbits.ODCD1
#define RX2_ANS                  ANSELDbits.ANSELD1
#define RX2_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define RX2_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define RX2_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define RX2_GetValue()           PORTDbits.RD1
#define RX2_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define RX2_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define RX2_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define RX2_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define RX2_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define RX2_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define RX2_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define RX2_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD4 aliases
#define CS1_TRIS                 TRISDbits.TRISD4
#define CS1_LAT                  LATDbits.LATD4
#define CS1_PORT                 PORTDbits.RD4
#define CS1_WPU                  WPUDbits.WPUD4
#define CS1_OD                   ODCONDbits.ODCD4
#define CS1_ANS                  ANSELDbits.ANSELD4
#define CS1_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define CS1_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define CS1_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define CS1_GetValue()           PORTDbits.RD4
#define CS1_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define CS1_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define CS1_SetPullup()          do { WPUDbits.WPUD4 = 1; } while(0)
#define CS1_ResetPullup()        do { WPUDbits.WPUD4 = 0; } while(0)
#define CS1_SetPushPull()        do { ODCONDbits.ODCD4 = 0; } while(0)
#define CS1_SetOpenDrain()       do { ODCONDbits.ODCD4 = 1; } while(0)
#define CS1_SetAnalogMode()      do { ANSELDbits.ANSELD4 = 1; } while(0)
#define CS1_SetDigitalMode()     do { ANSELDbits.ANSELD4 = 0; } while(0)

// get/set RE0 aliases
#define LED0_TRIS                 TRISEbits.TRISE0
#define LED0_LAT                  LATEbits.LATE0
#define LED0_PORT                 PORTEbits.RE0
#define LED0_WPU                  WPUEbits.WPUE0
#define LED0_OD                   ODCONEbits.ODCE0
#define LED0_ANS                  ANSELEbits.ANSELE0
#define LED0_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define LED0_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define LED0_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define LED0_GetValue()           PORTEbits.RE0
#define LED0_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define LED0_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define LED0_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define LED0_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define LED0_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define LED0_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define LED0_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define LED0_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set RE2 aliases
#define SW0_TRIS                 TRISEbits.TRISE2
#define SW0_LAT                  LATEbits.LATE2
#define SW0_PORT                 PORTEbits.RE2
#define SW0_WPU                  WPUEbits.WPUE2
#define SW0_OD                   ODCONEbits.ODCE2
#define SW0_ANS                  ANSELEbits.ANSELE2
#define SW0_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define SW0_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define SW0_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define SW0_GetValue()           PORTEbits.RE2
#define SW0_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define SW0_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define SW0_SetPullup()          do { WPUEbits.WPUE2 = 1; } while(0)
#define SW0_ResetPullup()        do { WPUEbits.WPUE2 = 0; } while(0)
#define SW0_SetPushPull()        do { ODCONEbits.ODCE2 = 0; } while(0)
#define SW0_SetOpenDrain()       do { ODCONEbits.ODCE2 = 1; } while(0)
#define SW0_SetAnalogMode()      do { ANSELEbits.ANSELE2 = 1; } while(0)
#define SW0_SetDigitalMode()     do { ANSELEbits.ANSELE2 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/