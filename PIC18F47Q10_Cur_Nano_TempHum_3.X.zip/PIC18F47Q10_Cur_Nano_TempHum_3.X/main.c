 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
 * Jan. 4, 2026
 * Dale R.
 * PIC18F47Q10 Curiosity Nano Board With Curiosity Nano Base
 * Mikroe TempHum 3 Click Board Installed mikro BUS Position 1
 * Microchip Data Visualizer Used To Display Data
 */

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/i2c_host/i2c_host_types.h"
#include "mcc_generated_files/i2c_host/mssp1.h"

#define HDC2010_ADDRESS 0x40
#define TEMPERATURE_REG_LOW 0x00
#define TEMPERATURE_REG_HIGH 0x01
#define HUMIDITY_REG_LOW 0x02
#define HUMIDITY_REG_HIGH 0x03
#define TEMP_OFFSET_ADJUST 0x08
#define HUM_OFFSET_ADJUST 0x09
#define RST_DRDY_INT_CONF_REG 0x0E
#define MEASUREMENT_CONFIG_REG 0x0F

uint8_t address = 0; 
uint8_t dataWrite[2] = {0};
uint8_t dataWriteLen = 0;
uint8_t dataRead[2] = {0};
uint8_t dataReadLen = 0;

const i2c_host_interface_t *I2C = &I2C1_Host;  /* From mssp1.h file */

/*
    Main application
*/

/* Function Declarations */
void ClearVars();
void HDC2010_Reset();
void HDC2010_Temp_Adjust();
void HDC2010_Hum_Adjust();
void HDC2010_Start_Measure();
void HDC2010_Read_Temperature();
void HDC2010_Read_Humidity();
void WriteToHDC2010(uint8_t address, uint8_t *dataWrite, uint8_t dataWriteLen);

int main(void)
{
    SYSTEM_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    //INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 

    CS1_SetLow();  /* Address select - CS pin */
    ClearVars();
    HDC2010_Reset();

    while(1)
    {    
    HDC2010_Start_Measure();
    HDC2010_Read_Temperature();
    HDC2010_Temp_Adjust();
    HDC2010_Read_Humidity();
    HDC2010_Hum_Adjust();
    
    __delay_ms(2000);    
    } /* End of while */ 
    
}  /* End of main */

/* Functions */
void ClearVars()
{
/* Clear the variables */
    address = 0;
    dataWrite[0] = 0;
    dataWrite[1] = 0;
    dataWriteLen = 0;
    dataRead[0] = 0;
    dataRead[1] = 0;
    dataReadLen = 0;
}

void HDC2010_Reset()
{
/* Reset the sensor */    
address = HDC2010_ADDRESS;
dataWrite[0] = RST_DRDY_INT_CONF_REG;
dataWrite[1] = 0x80;
dataWriteLen = 2;
WriteToHDC2010(address, dataWrite, dataWriteLen);
__delay_ms(80); 
ClearVars();
}

void HDC2010_Temp_Adjust()
{
/* Adjust temperature offset */
address = HDC2010_ADDRESS;
dataWrite[0] = TEMP_OFFSET_ADJUST;
dataWrite[1] = 0x01;
dataWriteLen = 2;
WriteToHDC2010(address, dataWrite, dataWriteLen);
__delay_ms(80); 
ClearVars();   
}

void HDC2010_Hum_Adjust()
{
/* Adjust humidity offset */
address = HDC2010_ADDRESS;
dataWrite[0] = HUM_OFFSET_ADJUST;
dataWrite[1] = 0xDD;
dataWriteLen = 2;
WriteToHDC2010(address, dataWrite, dataWriteLen);
__delay_ms(80); 
ClearVars();      
}

void HDC2010_Start_Measure()
{
/* Manual read mode */
address = HDC2010_ADDRESS;
dataWrite[0] = MEASUREMENT_CONFIG_REG;
dataWrite[1] = 0x01;
dataWriteLen = 2;   
WriteToHDC2010(address, dataWrite, dataWriteLen);
__delay_ms(80); 
ClearVars();    
}

void HDC2010_Read_Temperature()
{
/* Read the temperature */
uint8_t temp_low = 0;
uint8_t temp_high = 0; 
uint16_t raw_temp = 0;
float current_temperature = 0;
address = HDC2010_ADDRESS;
dataWrite[0] = TEMPERATURE_REG_LOW;
dataWrite[1] = 0;
dataWriteLen = 1;
dataRead[0] = 0;
dataRead[1] = 0;
dataReadLen = 2;
if (I2C->WriteRead(address, dataWrite, dataWriteLen, dataRead, dataReadLen))
      {
               
    while(I2C->IsBusy())
        {
        I2C->Tasks();
        }
    if (I2C->ErrorGet() == I2C_ERROR_NONE)
        { 
        /* Write operation is successful */
        }
    else
        {
        printf("Error in I2C Write Read\r\n");
        /* Error handling */
        }
       }  /* End of if statement */

    temp_low = dataRead[0];
    temp_high = dataRead[1];
    raw_temp = (temp_high << 8) | temp_low;
    current_temperature = (raw_temp / 65536.0) * 165.0 - 40.0;
    printf("Current temperature is: %.3f\r\n", current_temperature);
__delay_ms(80); 
ClearVars();       
}

void HDC2010_Read_Humidity()
{
/* Read the humidity */
uint8_t hum_low = 0;
uint8_t hum_high = 0; 
uint16_t raw_hum = 0;
float current_humidity = 0;
address = HDC2010_ADDRESS;
dataWrite[0] = HUMIDITY_REG_LOW;
dataWrite[1] = 0;
dataWriteLen = 1;
dataRead[0] = 0;
dataRead[1] = 0;
dataReadLen = 2;
if (I2C->WriteRead(address, dataWrite, dataWriteLen, dataRead, dataReadLen))
      {
               
    while(I2C->IsBusy())
        {
        I2C->Tasks();
        }
    if (I2C->ErrorGet() == I2C_ERROR_NONE)
        {
        /* Write operation is successful */
        }
    else
        {
        printf("Error in I2C Write Read\r\n");
        /* Error handling */
        }
       }  /* End of if statement */

    hum_low = dataRead[0];
    hum_high = dataRead[1];
    raw_hum = (hum_high << 8) | hum_low;
    current_humidity = (raw_hum / 65536.0) * 100.0;
    printf("Current humidity is: %.3f\r\n", current_humidity);
    printf("\r\n");
__delay_ms(80); 
ClearVars();                 
}


/* ******** I2C Function *********/

void WriteToHDC2010(uint8_t address, uint8_t *dataWrite, uint8_t dataWriteLen)
    {
    
     if (I2C->Write(address, dataWrite, dataWriteLen))
      {
               
    while(I2C->IsBusy())
        {
        I2C->Tasks();
        }
    if (I2C->ErrorGet() == I2C_ERROR_NONE)
        {
        
        /* Write operation is successful */
        }
    else
        {
        printf("Error in I2C Write\r\n");
        /* Error handling */
        }
       }  /* End of if statement */
        
            __delay_ms(50);
             
    } /* End of function */     
